const today_js = dayjs();
//exercise 15a
const dateString_js = today_js.add(5, "days");
const dateFormat_js = dateString_js.format("ddd-MMM-D");
let content = `
<p>${5} days is Added to ${today_js.format("ddd-MMM-D")}</p>
<p>So, The new date is ${dateString_js.format("ddd-MMM-D")}</p>
`;
document.querySelector(".exec15a").innerHTML = content;

//exercise 15b
const dateString_js15b = today_js.add(30, "days");
const dateFormat_js15b = dateString_js15b.format("ddd-MMM-D");
let content15b = `
<p>${1} month is Added to ${today_js.format("ddd-MMM-D")}</p>
<p>So, The new date is ${dateString_js15b.format("ddd-MMM-D")}</p>
`;
document.querySelector(".exec15b").innerHTML = content15b;

//exercise 15c
const dateString_js15c = today_js.subtract(30, "days");
let content15c = `
<p>${1} month is Subtract from ${today_js.format("ddd-MMM-D")}</p>
<p>So, The new date is ${dateString_js15c.format("ddd-MMM-D")}</p>
`;
document.querySelector(".exec15c").innerHTML = content15c;

//exercise 15d
const dateString_js15d = today_js.format("dddd");
document.querySelector(".dayoftheWeek").innerHTML =
  "Day of the week: " + dateString_js15d;

//exercise 15e
function isweekend(isweekend) {
  //let isweekend = today_js.format("dddd");
  if (isweekend === "Saterday" || isweekend === "Sunday") {
    return "Yes it is Weekend";
  } else {
    return "It is not Weekend. It is: " + isweekend;
  }
}
document.querySelector(".weekend").innerHTML = isweekend(
  today_js.format("dddd")
);
