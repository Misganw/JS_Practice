let score = JSON.parse(localStorage.getItem("score"));
if (!score) {
  score = {
    win: 0,
    loss: 0,
    tie: 0,
  };
}

function resetScore() {
  score.win = 0;
  score.loss = 0;
  score.tie = 0; 
   localStorage.removeItem("score");
}
function computerMove() {
  const randNumber = Math.random();
  let computerMove = "";
  if (randNumber >= 0 && randNumber <= 1 / 3) {
    computerMove = "rock";
  } else if (randNumber >= 1 / 3 && randNumber <= 2 / 3) {
    computerMove = "paper";
  } else if (randNumber >= 2 / 3 && randNumber <= 1) {
    computerMove = "scissor";
  }

  return computerMove;
}

function clickFunc(param) {
  let result = "";
  if (param === "rock") {
    if (computerMove() === "rock") {
      result = "win";
    } else if (computerMove() === "paper") {
      result = "loss";
    } else if (computerMove() === "scissor") {
      result = "Tie";
    }
  } else if (param === "paper") {
    if (computerMove() === "rock") {
      result = "loss";
    } else if (computerMove() === "paper") {
      result = "win";
    } else if (computerMove() === "scissor") {
      result = "Tie";
    }
  } else if (param === "scissor") {
    if (computerMove() === "rock") {
      result = "loss";
    } else if (computerMove() === "paper") {
      result = "Tie";
    } else if (computerMove() === "scissor") {
      result = "win";
    }
  }
  if (result === "win") {
    score.win += 1;
  } else if (result === "loss") {
    score.loss += 1;
  } else if (result === "Tie") {
    score.tie += 1;
  }
  localStorage.setItem("score", JSON.stringify(score));
  //alert('You picked '+param+'  '+ 'Computer picked '+ computerMove()+' '+ result);
  const res = `You picked ${param} Computer picked ${computerMove()}. So,${result}!!.`;
  document.getElementById("result").innerHTML = res;
  document.getElementById(
    "score"
  ).innerHTML = `Win:=${score.win} Loss:=${score.loss} Tie:=${score.tie}`;
}
let autoplaying=false;
let intervalId;
function autoplay(){
  if(!autoplaying)
  {
 intervalId=setInterval(()=>{
    const pMove=computerMove();
    clickFunc(pMove);
    console.log(autoplaying);
  },1000);
  autoplaying=true;
  }
 else{
  clearInterval(intervalId);
  autoplaying=false;
 }
}
//DOM for each button
document.querySelector('.rock').addEventListener('click',()=>{
clickFunc('rock');
});
document.querySelector('.paper').addEventListener('click',()=>{
clickFunc('paper');
});
document.querySelector('.scissor').addEventListener('click',()=>{
clickFunc('scissor');
});
//Keydown fucntion for each button

document.body.addEventListener('keydown',(e)=>{
  if(e.key==='r'){
    clickFunc('rock');
  }
  else if(e.key==='p'){
   clickFunc('paper');
  }
  else if(e.key==='s'){
   clickFunc('scissor');
  }

})